function params = countParams(hiddenConfig, inputSize, outputSize)
% Number of weight parameters
wts = [inputSize,hiddenConfig,outputSize] * [hiddenConfig,outputSize,0]';
% Number of bias parameters
biases = sum([hiddenConfig, outputSize]);
% Total
params =  wts + biases;
end