function [minNet, trainings, ranks, steps] = findMinimumNetwork(allConfigs, x, y, errorTol)

% how many restarts if performance goal not acheived
maxRestarts = 5;

% Number of network configuration to search through
netNo = length(allConfigs);

% initialise training stats variable
trainings = cell(floor(log2(netNo)),1);

% initialise ranks and steps variable
ranks = zeros(floor(log2(netNo)),1);
steps = zeros(floor(log2(netNo)),1);

% a counter to terminate the search process
iteration = 0;
step = 0;

while netNo > 0
    step = step + 1;
    thisNet = ceil(netNo./2);
     if thisNet == 1
         iteration = iteration + 1;
         if iteration > 1
             break
         end % if iteration
     end % if thisNet
    steps(step) = step;
    ranks(step) = allConfigs{thisNet,5};
    hiddenLayers = allConfigs{thisNet,3};
    restart = 0;
    while true
        [net, training] = testNet(hiddenLayers, x, y, errorTol);
        goodNet = strcmp(training.stop, 'Performance goal met.');
        if goodNet
            minNet = net;
            trainings(step) = {training};
            allConfigs = allConfigs(1:(thisNet-1),:);
            break
        else
            restart = restart + 1;
            if restart > maxRestarts
                trainings(step) = {training};
                allConfigs = allConfigs((thisNet+1):end,:);
                break
            end % if restart
        end % if goodNet
    end % while true
    netNo = size(allConfigs,1);
end % while netNo
end % findMinimumNetwork