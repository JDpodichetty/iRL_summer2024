%% This script is a road map for builiding a surrogate ANN model from a 
%  full-order QSP model
% Implementation of the approach proposed in the manuscript titled
% "Reduction of Quantitative Systems Pharmacology Models Using Artificial
% Neural Networks"
% Authors: Abdallah Derbalah, Hesham Al-Sallami, Stephen Duffull
clear
clc

%% Step 1: Create a sorted list of all possible network architectures
% the list is created based on the maximum number of parameters, neurons,
% and layers expected to be needed for approximating the full order model
% The architectures are then sorted based on approximation power.
% See manuscript section "ANN Architecture Selection"
% The sorted list is exported to the working directory as (...\allConfigs.mat)
% ==================
% This script requires the following function files
% A] findConfigurations.m
%   A function file that takes input layer size, output layer size, no. of
%   nodes, no of layers, and max no. of parameters and outputs a cell 
%   containing all possible configurations that satisfy those parameters. 
%   It also filters all configurations that are potentially inappropriate
%   as per manuscript section "ANN Architecture Selection"
% B] allVL1.m
%   A helper function, called by findConfigurations.m to generate all
%   integer premutations with a sum criteria. Written by Bruno Luong.
% C] countParams.m
%   A helper function composed of vectorised implementation of  equation 8
%   in the manuscript to count the number of paramters for a given
%   architecture.
% ==================

% Set options
maxParams = 372; % maximum number of network parmeters
maxNodes = 52; % corresponds to a 1-layer network with maxParams number
maxLayers = 5; % arbitrarily

% Create and export list
createSortedList

%% Step 2: Load Training and Evaluation Data
% two matrices are loaded:
%   x: a 4-by-Q matrix of input variables: weight(kg), age(days),
%       infusion amount(IU), infusion duration(hours)
%   y: a 2-by-Q matrix of output variables: aPTT(seconds), aXa(IU/mL)
% Q is the number of training examples. The nominal value of Q is 10,000.
% However, the actual Q is slightly smaller as some aXa values from the QSP
% model outputs where outside the calibration range and therefore were
% excluded

clear
clc

load trainingDataV03_2021.mat

%% Step 3: Find and train a minimum network architecture
% finds the minimum network architecture that can achieve a predefined
% performance goad (MSE).
%   Note that network training involves random intialisation of network
%   parameters which means each time this section of the code is run, it
%   would produce slightly different results compared with the reported.
%   It is not currently possible to set seed for all the parameter 
%   intialisation processes. 
% The trained network object for each MSE goad are exported to the working
% directory as (...\minNetsFullTraining.mat)
% ==================
% This script requires the following function files:
%   A] findMinimumNetwork.m
%       An implementation of the proposed modified binary search-based
%       algorithm to find the minimum network architecture that achieves a
%       given performance goal as per manuscript section "ANN Architecture
%       Selection" and figure 4.
%   B] testNet.m
%       Trains a given netwrok architecture and tests wehther the
%       evaluation performance is greater than the goal performance. Sets
%       options for MATLAB's train() function which implements the LM
%       training alogrithm
% ==================

% Load sorted list of all possible network architectures
load allConfigs.mat

% MSE performance goals
errorTols = [1e-3,1e-4,1e-5,1e-6];

ANNtraining

%% Step 4: Extract summary statistics of training process
% This script extracts key statistics about training, simulation and
% validation of ANNs that have been reported in the manuscript
clear
clc

trainingStats

%% Step 5: Validate Trained Networks
% This scripts creates four additional validation datasets and calculates
% the validation performances and error distributions for the trained ANNs
clear
clc

% load training data
load trainingDataV03_2021.mat

% Load authors-trained neural nets
load minNetsFullTraining.mat

ANNvalidation







