%% This file tests the peroformance of different trained neural nets on 
% the additional validation datasets
% The description of these datasets is provided in the manuscript under
% section "Simulation of pseudo data"
% Note that simulation of such datasets requires the full-order QSP model
% for which code is not included here. Instead, the simulated QSP outputs
% are provided as a data file (...\validationDataV03_2021.mat)

%% Load simulated responses
load validationDataV03_2021.mat

% range of outputs in training data
minY = min(y,[],2);
maxY = max(y,[],2);
filter = @(y) y<maxY&y>minY;

outOfRangeMask = cellfun(@(x) logical(prod(x)), cellfun(filter, yVal, 'Uni', 0), 'Uni', 0);

yVal = cellfun(@(matrix,mask) matrix(:,mask), yVal, outOfRangeMask, 'Uni', 0);

addVal = cellfun(@(matrix,mask) matrix(:,mask), addVal, outOfRangeMask, 'Uni', 0);

%% Simulate network outputs
% Initialise
o = cell(numel(minNets),numel(addVal));

% Simulate
for net = 1:length(minNets)
    for set = 1:length(addVal)
        thisNet = minNets{net}.netObject;
        thisSet = addVal{set};
        thisO = thisNet(thisSet);
        %thisO = mapminmax(thisNet(thisSet), thisNet.outputs{end}.processSettings{1});
        o{net,set} = thisO;
    end % for set
end % for net

%% calculate mse for each net/validation set combination

% extract the net object only
minNetsOnly = cellfun(@(x) x.netObject, minNets, 'Uni', 0);

thisMSE = cell(numel(minNets), numel(yVal));

for net = 1:length(minNetsOnly)
    for set = 1:length(yVal)
        thisY = yVal{set};
        thisX = addVal{set};
        thisNet = minNetsOnly{net};
        thisO = thisNet(thisX);
        thisMSE{net,set} = perform(thisNet,thisY,thisO);
    end % for set
end % for net

%% Error distribution of validation sets:
% OUTPUT: interpolationDat; a matrix whose each row represent an instance
% of validation data. Columns are: 1) validation set number, 2) ANN number
% 1:4 corresponding to networks A-D, 3) MSE of the respctive network on the
% respective validation set, 4) value of the validation variable, 5) value
% of the respective error instance
interpolationDat = [];

for net = 1:length(minNets)
    for set = 1:length(addVal)
       thisVar = addVal{set}(set,:)';
       thisY = yVal{set};
       thisNet = minNetsOnly{net};
       thisYnormalised = mapminmax(thisY, thisNet.outputs{end}.processSettings{1});
       thisO = o{net,set};
       thisOnormalised = mapminmax(thisO, thisNet.outputs{end}.processSettings{1});
       err = (thisYnormalised(1,:)-thisOnormalised(1,:))';
       thisMse = err'*err/numel(err);
       interpolationDat = [interpolationDat; [repmat([set, net, thisMse], length(err),1),thisVar,err]];
    end
end

save interpolationDat.mat interpolationDat

