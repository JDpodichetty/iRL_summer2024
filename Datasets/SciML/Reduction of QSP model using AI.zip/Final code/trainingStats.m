%% This script extracts summary stats about training of neural networks

load minNetsFullTraining.mat
%% search path: export to R for plotting
% Outputs a matrix in which each row represents an iteration in the binary
% search algorthm. The columns represent: 1) performance goal, 2) logical
% indicating whether the performance goal is achieved at the corresponding
% iteration, 3) evaluation performance (MSE), 4) rank of the ANN
% architecture tested at that iteration
dat = [];
for path = 1:length(minNets)
    thisPath = minNets{path};
    trngs = minNets{path}.trainings;
    goal = repmat(thisPath.perfGoal, size(trngs));
    performances = cellfun(@(x) x.best_perf, trngs);
    goalMet = performances <  goal;
    ranks = thisPath.ranks;
    dat = [dat; [goal, goalMet, performances, ranks]];
end

% Export data to the local working directory
save searchPath.mat dat

%% Stopping criteria
% This files counts the frequency of different criteria for training
% stopping
% Output: stops: a cell with 2 columns: 1) reason for stopping, 2)
% frequence

stop = cell(0);
for net = 1:length(minNets)
   thisNet = minNets{net};
   for step = 1:length(thisNet.trainings)
      thisStop = thisNet.trainings{step}.stop;
      stop = [stop; thisStop];
   end
end
stops = unique(stop);

for reason = 1:size(stops,1)
   stops{reason,2} = sum(strcmp(stops{reason,1}, stop));
end


%% Training time median and range
% range and median training time for all networks and performance goals
times = cellfun(@(x) cellfun(@(y) max(y.time), x.trainings), minNets, 'Uni', 0);
times = vertcat(times{:});

max(times)
min(times)
median(times)

%% Training epochs
% extracts the number of training epochs (iterations) for minimum nets in
% each perofrmance goal

% Get best min net index
performances = cellfun(@(x) cellfun(@(y) y.best_perf, x.trainings), minNets, 'Uni', 0);
goals = cellfun(@(x) x.perfGoal, minNets, 'Uni', 0);

minNetInd = cellfun(@(x,y) find(x<y, 1, 'last'), performances, goals, 'Uni',0);

% how many epochs for each net
epochs = cellfun(@(x,y) max(x.trainings{y}.epoch), minNets, minNetInd);

% how much time
times = cellfun(@(x,y) max(x.trainings{y}.time), minNets, minNetInd);

%% Simulation times

load trainingDataV03_2021.mat

simTimes = zeros(size(minNets));

% run this at least twice to get better estimates
for net = 1:numel(minNets)
    tic
    minNets{net}.netObject(x);
    simTimes(net) = toc;
end
simTimes

%% Data for training and validation errors distribution 
% OUTPUT: dat a Q-by-3 matrix whose each row represent an error instance
% and columns are: 1) performance goal, 2) ???? error, 3) ???? set

% Initialise the output matrix
dat = zeros(length(x).*length(minNets),3);

for i = 1:length(minNets)
    % output process settings
    PS = minNets{i}.netObject.outputs{end}.processSettings{1};
    yNorm = mapminmax(y, PS);
    
    % training and validation indecies
    T = minNets{i}.trainings{minNetInd{i}}.trainInd;
    V = minNets{i}.trainings{minNetInd{i}}.valInd;
%     trainSize = floor(length(x)*0.8);
%     evalSize = length(x)-trainSize;
%     T = 1:trainSize;
%     V = (trainSize+1):length(x);
    %
    o = minNets{i}.netObject(x);
    oNorm = mapminmax(o, PS);
    %
    errors = oNorm - yNorm;
    errorsT = errors(:,T);
    errorsV = errors(:,V);
    % set indicator variable: 1 training, 0 validation
    tSet = ones(size(T).*[1,2]);
    vSet = zeros(size(V).*[1,2]);
    %
    goal = ones(numel(errors),1).* minNets{i}.perfGoal;
    %
    rows = ((i-1)*numel(errors)+1):(i*numel(errors));
    %
    dat(rows,:) = [goal, [errorsT(:);errorsV(:)], [tSet(:);vSet(:)]];
end

save errorsHist.mat dat