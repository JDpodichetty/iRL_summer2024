function finalCell = findConfigurations(inputSize, hiddenSize, outputSize, maxParams)
% INPUT
%   inputSize: a scalar; the size of the input layer
%   hiddenSize: a 2-dimensional vector; number of nodes in the hidden
%               layers, no. of hidden layers
%   outputSize: a scalar; the size of the output layer
%   maxParams: the maximum no. of parameters for the architectures to be
%              generated

% OUTPUT
%   finalCell: a n-by-1 cell, where n is the number of architecture
%   staisfying the input criteria. Each element in the cell is a 1-by-3
%   cell describing a single architecture; 1] a 2-by-1 vector of no. of
%   hidden neurons and hidden layers, 2] no. of neurons in each hidden
%   layer (configuration), 3] no. of parameters

nNodes = hiddenSize(1);
nLayers = hiddenSize(2);

if nNodes == 1
    finalCell = [num2cell([1,1],[1,2]), num2cell(1), num2cell(inputSize+1+outputSize.*2)];
    return
end
config = allVL1(nLayers,nNodes);

% remove nets that have layers with zero nodes
config = config(prod(config,2)~=0,:);

% every layer should have nNodes <= previous layer, first layer >=
% inputSize, and last layer >= outputSize
if nLayers > 1 && nNodes > inputSize
    first = config(:,1) >= inputSize;
    last = config(:,end) >= outputSize;
    middle = logical(prod(arrayfun(@(x) x<=0, diff(config,1,2)),2));
    config = config(first&middle&last,:);
end
configCell = num2cell(config,2);

% get no of params
getParam = @(x) countParams(x, inputSize, outputSize);
nParam = cellfun(getParam, configCell);

% sort by number of parameters
[nParamSorted,I] = sort(nParam);
configCell = [configCell(I), num2cell(nParamSorted,2)];
configCell = configCell(nParamSorted <= maxParams,:);

finalCell = [num2cell(repmat(hiddenSize,size(configCell,1),1),2), configCell];
end