function [net,training] = testNet(hiddenLayers, x, y, errorTol)
% create network object
net = feedforwardnet([hiddenLayers]);
% set options
net.trainParam.epochs = 1000;
net.trainParam.max_fail = 1000;
net.trainParam.goal = errorTol;
net.divideFcn = 'divideblock';
net.divideParam.trainRatio = 0.8;
net.divideParam.valRatio = 0.2;
net.divideParam.testRatio = 0;
% normalisation of outputs so that they are equally important
% for furhter detail: https://au.mathworks.com/help/deeplearning/ref/mse.html
net.performParam.normalization = 'standard';
[net,training] = train(net, x,y);
end