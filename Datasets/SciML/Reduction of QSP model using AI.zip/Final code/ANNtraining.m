%% This script file finds and trains a minimum network architecture that 
% achives a given MSE performance goal
% Output: struct with the following fields:
% A] prefGoal:
%   MSE performance goal
% B] netObject:
%   The trained ANN object for the corresponding performance goal
% C] trainings:
%   training record
% D] ranks:
%   the ranks of networks tested at each iteration in the binary search 
%   process.
% E] steps:
%   The iteration number of the binary search process

allRankings = (1:size(allConfigs,1))';
allConfigs = [allConfigs, mat2cell(allRankings,ones(size(allRankings,1),1), 1)];


minNets = cell(numel(errorTols),1);

parfor tol = 1:numel(errorTols)
    errorTol = errorTols(tol);
    [minNet, trainings, ranks, steps] = findMinimumNetwork(allConfigs, x, y, errorTol);
    minNets{tol} = struct('perfGoal', errorTol, ...
        'netObject', minNet, ...
        'trainings', {trainings}, ...
        'ranks', ranks, ...
        'steps', steps);
    fprintf('finished tol %d\n', errorTol)
end

save minNetsFullTraining.mat minNets