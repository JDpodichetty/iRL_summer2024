%% This script files creates a Create a sorted list of all possible network
% architectures that  satisfy some maximum size conditions

% All possible combinations of no of nodes and no of layers
x = combvec(1:maxNodes,1:maxLayers)';

% remove all nNodes<nLayers: at least one node per hiddern layer
x = x(x(:,1)>=x(:,2),:);

% Sort by number of layers then number of nodes, ascending
x = sortrows(x, [2,1]);

% Convert to cell to enable vectorised implementation of functions
nets = num2cell(x, 2);

% inputs are 4: wt, age, infusion rate, and duration
inputSize = 4;

% outputs are 2: aPTT and aXa
outputSize = 2;

% get all possible configurations
getConfig = @(x) findConfigurations(inputSize, x, outputSize, maxParams);
allConfigs = cellfun(getConfig, nets, 'Uni', 0);

% unnest cell
allConfigs = vertcat(allConfigs{:});

% unnest first column of cell so that you get the follwoing cols
% columns: nNodes, nLayers, hiddenConfig, nParameters
allConfigs = [num2cell(vertcat(allConfigs{:,1})) allConfigs(:,2:end)];

% sort by nNodes, nLayers, nParams, meanNodes
maxNodes = cellfun(@(x) mean(abs(diff(x))), allConfigs(:,3));
[~, ind] = sortrows([ [allConfigs{:,1}]', [allConfigs{:,2}]', [allConfigs{:,4}]', maxNodes ],[1:3,-4]);
allConfigs = allConfigs(ind,:);

% the x variable is used elsewhere so delete it to avoid bugs
clear x

% export to working directory
save allConfigs.mat allConfigs
