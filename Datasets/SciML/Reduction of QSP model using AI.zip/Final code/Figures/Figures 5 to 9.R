setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
library(R.matlab) # for readMat()
library(tidyverse) # for as_tibble(), %>%(), mutate(), select(), ggplot(), and others
library(ggpubr) # for annotate_figure(), ggarrange(), and get_legend()
library(cowplot) # for plot_grid()
##



##### FIGURE 5 #####
# Histogram of training data
# table variable names
variableNames = c("wt", "age", "infusionAmount", "duration", "aptt", "xa", "train", "val")
Labels = c("Weight (Kg)", "Age (Years)", "Infusion Amount (IU)", "Infusion Duration (Hours)", "aPTT (Seconds)", "Anti-Xa (IU/mL)")
names(Labels) = variableNames[1:length(Labels)]
#

df = readMat("RhistogramData2.mat") %>% 
  `[[`(1) %>% 
  as_tibble(.name_repair = ~variableNames) %>%
  mutate(set = if_else(train == 1, "Training", "Validation"),
         age = age/365) %>%
  select(-train, -val)
#


# a function to plot a single variable as a histogram
onePlot = function(df, x, legend){
  ggplot(df, aes_string(x)) +
  geom_histogram(aes(fill = set), color = "black", show.legend = legend) +
  theme_bw()+
  scale_fill_discrete(name = NULL) + 
  labs(x = Labels[x], y = NULL) +
  theme(axis.text = element_text(face = "bold", size = rel(1.2)),
        legend.title = element_text(face = "bold"),
        legend.text = element_text(face = "bold"),
        axis.title = element_text(face = "bold", size = rel(1.2)),
        panel.border = element_blank(),
        panel.grid = element_blank(),
        axis.line = element_line(size = 1),
        legend.position = "top",
        legend.direction = "horizontal")
}

# get one common legend
legend = get_legend(onePlot(df, "wt", TRUE))

# plot all variables without legends
plots = sapply(1:6, function(x) onePlot(df, variableNames[x], FALSE), simplify = FALSE)

# Combine Plots and legend

allPlot = annotate_figure(do.call(ggarrange, c(plots,
                                               list(ncol = 2,
                                                    nrow = ceiling(length(plots)/2)))),
                          left = text_grob("Frequency", face = "bold",size = 16, rot = 90))
plot_grid(legend, allPlot, ncol = 1, nrow = 2, rel_heights = c(1/8,1))

# save Plot
ggsave("Figure 5.jpg", width = 6.98, height = 4.53*1.5)



##### FIGURE 6 #####

## Plot search Path data

variableNames = c("goal", "goalMet", "performance", "rank")
labels = c("Performance Goal", "Performance Goal Achieved", "Performance", "Architecture rank")
names(variableNames) = labels

df = readMat("searchPath.mat") %>% 
  `[[`(1) %>% 
  as_tibble(.name_repair = ~variableNames) %>%
  group_by(goal) %>%
  mutate(step = row_number()) 

df2 = df %>% group_by(goal) %>% mutate(successfulStep = if_else(goalMet == 1, step, NA_integer_),
                                       xPos = max(successfulStep, na.rm = TRUE),
                                       label = if_else(step == 13, goal, NA_real_)) %>%
  ungroup() %>%
  mutate(label = factor(label, labels = c("D","C","B","A")),
         label = as.character(label),
         yPos = case_when(label == "C" ~ (rank + 20),
                          label == "A" ~ (rank - 25),
                          label == "B" ~ (rank + 10),
                          TRUE ~ rank))

ggplot(df2 %>%
         filter(step > 2),
       aes(x = step, y = rank)) +
  geom_point(aes(color = factor(goalMet), shape = factor(goal)), size = 3) +
  geom_line(aes(color = factor(goalMet), group = factor(goal)), size = 1) +
  geom_text(aes(x = xPos, y = yPos, label = label),
            nudge_x = 0.3,
            nudge_y = 10,
            fontface = "bold") +
  theme_bw()+
  theme(axis.text = element_text(face = "bold"),
        legend.title = element_text(face = "bold", size = 12),
        legend.text = element_text(),
        axis.title = element_text(face = "bold", size = rel(1.2)),
        panel.grid = element_line(color = "grey")) +
  labs(x = "Experiment Number",
       y = "Architecture Rank",
       color = "Goal Achieved",
       shape = "Performance\nGoal (MSE)") +
  scale_shape_manual(values = c(18,15,16,17), labels = c(expression(10^-6), expression(10^-5), expression(10^-4), expression(10^-3 ))) +
  scale_color_manual(values = c("red3", "springgreen4"), labels = c("No", "Yes")) +
  scale_x_continuous(breaks = 3:13, minor_breaks = NULL) +
  scale_y_continuous(breaks = seq(0,1800,200))

#

ggsave("Figure 6.jpg", width = 8)



#### FIGURE 7 ####

### Errors boxplots

variableNames = c("goal", "error", "set")
df = readMat("errorsHist.mat") %>%
  `[[`(1) %>%
  as_tibble(.name_repair = ~variableNames) 

ggplot(df, aes(y = error)) +
  geom_boxplot(aes(fill = factor(set, levels = c(1,0),
                                 labels = c("Training", "Validation")),
                   x = factor(desc(goal), labels = LETTERS[1:length(unique(df$goal))])),
               show.legend = TRUE) +
  theme_bw()+
  labs(x = "Network", y = "Approximation Errors") +
  theme(axis.text = element_text(face = "bold", color = "black"),
        legend.title = element_text(face = "bold"),
        legend.text = element_text(face = "bold"),
        axis.title = element_text(face = "bold", size = rel(1.2)),
        panel.grid = element_blank(),
        legend.position = "top",
        legend.direction = "horizontal",
        strip.text = element_text(face = "bold"),
        panel.border = element_rect(size = 1.2, color = "black")) +
  scale_fill_discrete(name = NULL) +
  geom_abline(slope = 0, intercept = 0, lty = 2, color = "red", size = 0.85)

ggsave("Figure 7.jpg")



#### FIGURE 8 ####

variableNames = c("variable", "net", "mse", "value", "error")

Xaxis = c("Weight (Kgs)", "Age (Years)", "Infusion Amount (IU/mL)", "Infusion Duration (Hours)")

df = readMat("interpolationDat.mat") %>% 
  `[[`(1) %>% 
  as_tibble(.name_repair = ~variableNames)

names(Xaxis) = as.character(unique(df$variable))

mseCategories = c("> 0.1", "0.01-0.1", "0.001-0.01", "0.0001-0.001", "< 0.0001")

##
##
fancy_scientific <- function(l) { 
  # turn in to character string in scientific notation 
  l <- format(l, digits = 3, scientific = TRUE) 
  # quote the part before the exponent to keep all the digits 
  l <- gsub("^(.*)e", "'\\1'e", l) 
  # turn the 'e+' into plotmath format 
  l <- gsub("e", "%*%10^", l) 
  # return this as an expression 
  parse(text=l) 
} 
##
##

df_text = df %>% 
  mutate(y = 0.75*(max(error) - min(error))- 0.12*max(error)*(as.numeric(net)-1),
         ymax = max(error)*1.05,
         net = factor(net, labels = LETTERS[1:length(unique(net))])) %>%
  group_by(variable) %>%
  mutate(xmin = unique(net)[3],
         xmax = unique(net)[4]) %>%
  distinct(variable, net, .keep_all = TRUE) %>%
  mutate(mse = as.character(fancy_scientific(round(mse,7))))

  

ggplot(df, aes(x = factor(net, labels = LETTERS[1:length(unique(net))]), y = error)) +
  geom_boxplot(aes(color = factor(net, labels = LETTERS[1:length(unique(net))])), show.legend = F, size = 0.8) +
  theme_light()+
  geom_abline(slope = 0, intercept = 0, color = "black", lty = 5)+
  facet_wrap(~variable,
             scales = "free_x",
             strip.position = "top",
             labeller = labeller(variable = Xaxis)) +
  scale_color_manual(values = c("springgreen4", "red3", "darkorchid1", "royalblue", "maroon1")) +
  labs(x = "Network",
       y = "Approximation Errors",
       color = "Network") +
  theme(axis.text = element_text(face = "bold", color = "black"),
        legend.title = element_text(face = "bold"),
        legend.text = element_text(face = "bold"),
        axis.title = element_text(face = "bold", size = rel(1.2)),
        strip.text = element_text(face = "bold")) +
  geom_rect(data = df_text,
            aes(xmin = xmin,
                xmax = xmax,
                ymin = y - y*0.2,
                ymax = ymax - ymax*0.019),
            fill = "white",
            color = "black") +
  geom_text(data = df_text,
            aes(x = xmax, y = y, label = mse, color = net),
            parse = TRUE,
            size = 3,
            show.legend = FALSE,
            fontface = "bold",
            nudge_x = -0.5)

ggsave("Figure 8.jpg")



#### FIGURE 9 ####
## Simulating QSP vs ANN

variableNames = c("id", "time", "apttQSP", "xaQSP", "apttA", "xaA", "apttB", "xaB", "apttC", "xaC", "apttD", "xaD")

#

df = readMat("QSPvsANNtwoPatients.mat") %>% 
  `[[`(1) %>% 
  as_tibble(.name_repair = ~variableNames)

df = df %>% pivot_longer(c(apttQSP, apttA, apttB, apttC, apttD),
                         names_to = "apttModel",
                         values_to = "apttValue") %>%
  pivot_longer(c(xaQSP, xaA, xaB, xaC, xaD),
               names_to = "xaModel",
               values_to = "xaValues")

df = df %>% mutate(line = factor(if_else(apttModel == "apttQSP", 1, 2)))

df = df %>% mutate(apttModel = relevel(as.factor(apttModel), "apttQSP"))


###

# Plot1: aptt
p1 = ggplot(df, aes(x = time, y = apttValue)) +
  geom_line(aes(color = apttModel, linetype = apttModel), size = 1) +
  facet_wrap(~ id, nrow = 2) +
  labs(color = "name", linetype = "name", x = NULL, y = NULL)+
  theme_bw() +
  theme(legend.position = "none")

# Plot 2: xa
p2 = ggplot(df, aes(x = time, y = xaValues)) +
  geom_line(aes(color = xaModel, linetype = xaModel), size = 1) +
  facet_wrap(~ id, nrow = 2) +
  scale_y_continuous(position = "right") +
  labs(x = NULL, y = NULL) +
  theme_bw() +
  theme(legend.position = "none")

# legend:
L = get_legend(
  ggplot(df, aes(x = time, y = apttValue)) +
    geom_line(aes(color = apttModel, linetype = apttModel), size = 1) +
    facet_wrap(~ id, nrow = 2) +
    labs(color = NULL, linetype = NULL, x = NULL, y = NULL)+
    theme_bw() +
    theme(legend.position = "top") +
    scale_color_discrete(labels = c("QSP",
                                    "A",
                                    "B",
                                    "C",
                                    "D")) +
    scale_linetype_discrete(labels = c("QSP",
                                       "A",
                                       "B",
                                       "C",
                                       "D"))
)

# Combine and annotate
noLegend = ggarrange(p1, p2, ncol = 2, nrow = 1) %>%
  annotate_figure(left = text_grob("aPTT (Seconds)", face = "bold", rot = 90),
                  right = text_grob("Anti-Xa (IU/ml)", face = "bold", rot = 90),
                  bottom = text_grob("Time (Hours)", face = "bold"))
withLegend = plot_grid(L, noLegend, ncol = 1, nrow = 2, rel_heights = c(1,9))
withLegend
ggsave("Figure 9.jpg", withLegend)


